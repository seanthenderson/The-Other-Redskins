***Contents of the Zip Folder*** 

This zip file contains components for a special Capital News Project called "The Other Redskins: High Schools Debate Dropping a Controversial Mascot."  It looks at the 62 U.S. high schools that currently use the Redskins name and the 28 that have abandoned it over the last 25 years.  The project fact-checks some key assertions by the Washington Redskins in the growing debate over whether the team should change its name.  

The full project, built on a responsively designed microsite, is available to link to here: http://cnsmaryland.org/interactives/other-redskins/index.html.  

The full site that you see at that link is available for rehosting on your website by putting the "Full-Project-Microsite" folder onto your server.      

Most of the component parts of that micros site -- text stories, interactive maps, interactive tables and an image header -- are available in the other files in the zip folder to use as you choose.  We ask that you please retain bylines and credit lines.  

Please email CNS Studio C bureau director Sean Mussenden smussenden@jmail.umd.edu or smussenden@gmail.com with questions or call his cell, 202-590-2190. 

***In "Text" Folder in Zip File*** 

^OTHERREDSKINS-TEXT<
COLLEGE PARK --Washington Redskins executives, as part of a PR campaign to defend the continued use of a name many consider a racial slur, have pointed to U.S. high schools that use the name proudly.  In a series of "news stories" on the team website, the Redskins highlighted four high schools where coaches and principals said there is little or no debate in their communities about changing the name.  A Capital News Service investigation found that the schools highlighted by the NFL team do not accurately capture the state of debate over the name at the 62 high schools across the country that use the name.  CNS also found that the Redskins' PR campaign likely overstated the number of U.S. high schools that use the name, because they relied on an inaccurate data set.  The team said there were 70 schools, using flawed data from MaxPreps.com. The team has also not acknowledged, as CNS discovered, that 28 high schools have dropped the controversial name over the last 25 years.  CNS identified an additional eight schools that could drop the name soon because of legal challenges and community pressure.  An examination of how the debate over the name Redskins is happening not just in Washington, D.C., but also in communities across the country. SLUG: CNS-OtherRedskins Text, 3200 words.
By Kelyn Soong and CNS Staff.         

^OTHERREDSKINS-SHORTTEXT<
COLLEGE PARK -- A shortened version of the OTHERREDSKINS TEXT, for those who do not want to run a 3,200 word story.  SLUG: CNS-OtherRedskins ShortText, 1700 words.  
By Kelyn Soong and CNS Staff.

^OTHERREDSKINS-ABOUT<
COLLEGE PARK -- Background on how Capital News Service found and confirmed the list of 62 schools that use the name Redskins and the 28 schools that have dropped the name over the last 25 years, with information showing what our research shows and does not show.  The nerd box. SLUG: CNS-OtherRedskins About, 600 words.
By Kelyn Soong and CNS Staff.  

^OTHERREDSKINS-FRAME<
COLLEGE PARK -- A sidebar story providing background about the history of the debate over the Washington Redskins name, explaining why the debate has heated up in recent months. SLUG: CNS-OtherRedskins Frame, 300 words.      
By Kelyn Soong and CNS Staff. 

***In "Project Header" Folder in Zip File*** 

^OTHERREDSKINS-HEADER<
COLLEGE PARK - A 600px wide graphic (PNG file) for use with the story that reads "The Other Redskins: High Schools Debate Dropping a Controversial Mascot." 

***In "Maps" Folder in Zip File*** 

^OTHERREDSKINS-CURRENTMAP<
COLLEGE PARK -- A Google Earth map showing logos, location, school website and demographic information for each of the 62 high schools that currently use the Redskins name.  
By Sean Henderson and CNS Staff.

^OTHERREDSKINS-OLDMAP<
COLLEGE PARK -- An Google Earth map showing each of the 28 high schools that once used the Redskins name but have switched to a new one over the last 25 years. 
By Sean Henderson and CNS Staff.

NOTE: Because the maps are responsive, we are unable to provide iframes for embedding these components, as they resize depending on the device and browser size.  They will need to be hosted on your server.  If you are unable to do that, please direct readers to http://cnsmaryland.org/interactives/other-redskins/index.html to view them.  Please note that the Google Earth maps will not work on some mobile devices. 

***In "Tables" Folder in Zip File*** 

^OTHERREDSKINS-CURRENTTABLE<
COLLEGE PARK -- A sortable table showing the 62 high schools that currently use the Redskins name, with logos, city, state, school name and racial demographic information on student body.   
By Sean Henderson and CNS Staff.

^OTHERREDSKINS-OLDTABLE<
COLLEGE PARK -- A sortable table showing the 28 high schools that once used the Redskins name with new logo, city, state, school name and year switch to a new name occurred.     
By Sean Henderson and CNS Staff. 

NOTE: Because the tables are responsive, we are unable to provide iframes for embedding these components, as they resize depending on the device and browser size.  They will need to be hosted on your server.  If you are unable to do that, please direct readers to http://cnsmaryland.org/interactives/other-redskins/index.html to view them. 

--30--
